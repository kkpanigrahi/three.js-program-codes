# Three.js starter
A simple Three.js starter template

Make sure you have nodejs installed.

```
# Install dependencies (only the first time)
npm install

# Run the local server at localhost:1234
npm run dev

# Build for production in the /dist directory
npm run build
```
